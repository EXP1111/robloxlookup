import tkinter as tk

# Create the main window
root = tk.Tk()
root.title("My App")

# Create a label and a button
label = tk.Label(root, text="Hello!")
label.pack(padx=16, pady=8)


def say_hello():
	label.config(text="You clicked the button!")


button = tk.Button(root, text="Click me", command=say_hello)
button.pack(padx=16, pady=8)

# Keep the window open
root.mainloop()
